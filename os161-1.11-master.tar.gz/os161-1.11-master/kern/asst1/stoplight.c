/*
 * stoplight.c
 *
 * 31-1-2003 : GWA : Stub functions created for CS161 Asst1.
 *
 * NB: You can use any synchronization primitives available to solve
 * the stoplight problem in this file.
 */


/*
 *
 * Includes
 *
 */

#include <types.h>
#include <lib.h>
#include <test.h>
#include <thread.h>

#include <synch.h>//include this to avoid warnings

struct lock *printlock; // lock to protect print statements

struct lock *ABlock;//locks
struct lock *BClock;
struct lock *CAlock;

int numLeftTurns = 0;
struct lock *leftTurnLock;

// locks for prioritizing cars and trucks, in each lane
struct lock *prioCarsLockA; // lane A
int numCarsA = 0;

struct lock *prioCarsLockB; // lane B
int numCarsB = 0;

struct lock *prioCarsLockC; // lane C
int numCarsC = 0;

/*
 *
 * Constants
 *
 */
int ABstatus = 0;
int BCstatus = 0;//these status variables will keep track of availability of the zones, zero denotes available and 1 will mean occupied
int CAstatus = 0;//might not use it actually....

static const char *msg[] = {"Approaching: ","AB= ","BC= ","CA= ", "Leaving: "};//two arrays of strings consisting of message headers and route directions
static const char *routes[] = {"Route A", "Route B","Route C"};//for the vehicle direction
static const char *type[] = {"Car","Truck"};
enum{APPROACHING,AB,BC,CA,LEAVING};//the header arg of messenger, use this to select from msg array
/*
 * Number of vehicles created.
 */

#define NVEHICLES 20


/*
 *
 * Function Definitions
 *
 */
static void messenger(int header, int carnum, int cartype, int approachfrom, int destination){//function for printing messages with crucial information to the screen
    lock_acquire(printlock);
	kprintf("\n%s %s=%d, approaching direction=%s, destination=%s\n",msg[header],type[cartype],carnum, routes[approachfrom], routes[destination]);
	lock_release(printlock);
}
/* leaving();
 * arguments: vehicleType. if this is either a truck or a car?
 * Called when vehicle leaves the intersection.
 * 
 * if its a car, decrement numCars and release vehicleLock
 * so that the truck threads will wake up.
 * */
static void leaving(int vehicleType, int vehDirection){

	if(vehDirection == 0){ // lane A
		lock_acquire(prioCarsLockA);
		if(vehicleType==0){
			numCarsA--;
		}
		lock_release(prioCarsLockA);

		if(numCarsA == 0){
			int spl;
			spl = splhigh();
			thread_wakeup(prioCarsLockA);
			splx(spl);
		}
	}
	else if(vehDirection== 1){ // lane B
		lock_acquire(prioCarsLockB);
		if(vehicleType==0){
			numCarsB--;
		}
		lock_release(prioCarsLockB);

		if(numCarsB == 0){
			int spl;
			spl = splhigh();
			thread_wakeup(prioCarsLockB);
			splx(spl);
		}
	
	}
	else if(vehDirection== 2){ // lane C
		lock_acquire(prioCarsLockC);
		if(vehicleType==0){
			numCarsC--;
		}
		lock_release(prioCarsLockC);

		if(numCarsC == 0){
			int spl;
			spl = splhigh();
			thread_wakeup(prioCarsLockC);
			splx(spl);
		}
	}
}

/**/
static
void
sleepifbusy(int vehicleType, int vehDirection){
	// sleep truck if each lane is busy

	if(vehDirection == 0){ 
		if(numCarsA >= 1 ){
			if(vehicleType == 1){
				int spl = splhigh();
				thread_sleep(prioCarsLockA);
				splx(spl);	
			}
		}
	}
	else if(vehDirection== 1){ // lane B
		if(numCarsB >= 1 ){
			if(vehicleType == 1){
				int spl = splhigh();
				thread_sleep(prioCarsLockB);
				splx(spl);	
			}
		}
	}
	else if(vehDirection== 2){ // lane C
		if(numCarsC >= 1 ){
			if(vehicleType == 1){
				int spl = splhigh();
				thread_sleep(prioCarsLockC);
				splx(spl);	
			}
		}
	}
}

/*
 * turnleft()
 *
 * Arguments:
 *      unsigned long vehicledirection: the direction from which the vehicle
 *              approaches the intersection.
 *      unsigned long vehiclenumber: the vehicle id number for printing purposes.
 *
 * Returns:
 *      nothing.
 *
 * Notes:
 *      This function should implement making a left turn through the
 *      intersection from any direction.
 *      Write and comment this function.
 */

static
void
turnleft(unsigned long vehicledirection,
		unsigned long vehiclenumber,
		unsigned long vehicletype)
{
	/*
	 * Avoid unused variable warnings.
	 */

	(void) vehicledirection;
	(void) vehiclenumber;
	(void) vehicletype;
	int vehicledestination;
	if(vehicledirection == 0){
        vehicledestination = 2;//turning left on route A brings to route C

        //approach
        messenger(APPROACHING, vehiclenumber,vehicletype,vehicledirection,vehicledestination);
		sleepifbusy(vehicletype, vehicledirection);
        //move to AB
        lock_acquire(ABlock);
        ABstatus = 1;//set that region to occupied status
        messenger(AB,vehiclenumber,vehicletype,vehicledirection,vehicledestination);
        ABstatus = 0;

        //move to BC
        lock_acquire(BClock);
        BCstatus = 1;//set BC to occupied
        messenger(BC,vehiclenumber,vehicletype,vehicledirection,vehicledestination);
        BCstatus = 0;//set BC status to available
        lock_release(ABlock);//release the previous lock
        messenger(LEAVING,vehiclenumber,vehicletype,vehicledirection, vehicledestination);
		lock_release(BClock);//release the second region lock that is passed through in this left turning scenario of going from route A to C
		leaving(vehicletype, vehicledirection);

	}
	else if (vehicledirection == 1){
        vehicledestination = 0;//turning left at route B brings to route A

        //approach the route B
        messenger(APPROACHING, vehiclenumber,vehicletype, vehicledirection,vehicledestination);
		sleepifbusy(vehicletype, vehicledirection);
        //move to BC
        lock_acquire(BClock);
        messenger(BC,vehiclenumber,vehicletype,vehicledirection,vehicledestination);
        //move to CA region
        lock_acquire(CAlock);
        messenger(CA, vehiclenumber,vehicletype,vehicledirection,vehicledestination);
        lock_release(BClock);//releases previous lock
        messenger(LEAVING,vehiclenumber,vehicletype,vehicledirection,vehicledestination);
		lock_release(CAlock);
		leaving(vehicletype,vehicledirection);
	}
	else if (vehicledirection == 2){
        vehicledestination = 1;//moving from route C to route B by left turn

        messenger(APPROACHING, vehiclenumber,vehicletype,vehicledirection,vehicledestination);//approach the route C
		sleepifbusy(vehicletype, vehicledirection);

        //move to CA
        lock_acquire(CAlock);
        messenger(CA,vehiclenumber,vehicletype,vehicledirection,vehicledestination);
        //move to AB region
        lock_acquire(ABlock);
        ABstatus = 1;
        messenger(AB, vehiclenumber,vehicletype,vehicledirection,vehicledestination);
        ABstatus=0;
        lock_release(CAlock);
        messenger(LEAVING,vehiclenumber,vehicletype,vehicledirection,vehicledestination);
		lock_release(ABlock);
		leaving(vehicletype, vehicledirection);
	}
}


/*
 * turnright()
 *
 * Arguments:
 *      unsigned long vehicledirection: the direction from which the vehicle
 *              approaches the intersection.
 *      unsigned long vehiclenumber: the vehicle id number for printing purposes.
 *
 * Returns:
 *      nothing.
 *
 * Notes:
 *      This function should implement making a right turn through the
 *      intersection from any direction.
 *      Write and comment this function.
 */

static
void
turnright(unsigned long vehicledirection,
		unsigned long vehiclenumber,
		unsigned long vehicletype)
{
	/*
	 * Avoid unused variable warnings.
	 */

	(void) vehicledirection;
	(void) vehiclenumber;
	(void) vehicletype;
	int vehicledestination;

	if(vehicledirection==0){//from route A turn right onto route B
        vehicledestination = 1;

        messenger(APPROACHING, vehiclenumber,vehicletype, vehicledirection,vehicledestination);//approach route A
		sleepifbusy(vehicletype, vehicledirection);
        lock_acquire(ABlock);
        messenger(AB,vehiclenumber,vehicletype,vehicledirection,vehicledestination);
		messenger(LEAVING,vehiclenumber,vehicletype,vehicledirection,vehicledestination);
        lock_release(ABlock);
		leaving(vehicletype, vehicledirection);
	}
	else if(vehicledirection==1){//from route B turn right onto route C
        vehicledestination = 2;

        messenger(APPROACHING, vehiclenumber,vehicletype, vehicledirection,vehicledestination);//approach route B
		sleepifbusy(vehicletype, vehicledirection);
        lock_acquire(BClock);
        messenger(BC,vehiclenumber,vehicletype,vehicledirection,vehicledestination);
        messenger(LEAVING,vehiclenumber,vehicletype,vehicledirection,vehicledestination);
		lock_release(BClock);
		leaving(vehicletype, vehicledirection);
        
	}
	else if(vehicledirection==2){//from route C turn right onto route A
        vehicledestination = 0;

        messenger(APPROACHING, vehiclenumber, vehicletype, vehicledirection,vehicledestination);//approach route C
		sleepifbusy(vehicletype, vehicledirection);
        lock_acquire(CAlock);
        messenger(CA,vehiclenumber,vehicletype,vehicledirection,vehicledestination);
	    messenger(LEAVING,vehiclenumber,vehicletype,vehicledirection,vehicledestination);
        lock_release(CAlock);
		leaving(vehicletype, vehicledirection);

	}
}


/*
 * approachintersection()
 *
 * Arguments:
 *      void * unusedpointer: currently unused.
 *      unsigned long vehiclenumber: holds vehicle id number.
 *
 * Returns:
 *      nothing.
 *
 * Notes:
 *      Change this function as necessary to implement your solution. These
 *      threads are created by createvehicles().  Each one must choose a direction
 *      randomly, approach the intersection, choose a turn randomly, and then
 *      complete that turn.  The code to choose a direction randomly is
 *      provided, the rest is left to you to implement.  Making a turn
 *      or going straight should be done by calling one of the functions
 *      above.
 */

static
void
approachintersection(void * unusedpointer,
		unsigned long vehiclenumber)
{
	int vehicledirection, turndirection, vehicletype;

	/*
	 * Avoid unused variable and function warnings.
	 */

	(void) unusedpointer;
	(void) vehiclenumber;
	(void) turnleft;
	(void) turnright;

	/*
 	 * vehicledirection is set randomly.
	 */
	vehicledirection = random() % 3;
	turndirection = random() % 2;
	vehicletype = random() % 2;


	// Count up total number of cars and trucks on each Lane
	if(vehicledirection == 0){ // lane A
		if(vehicletype == 0){
			lock_acquire(prioCarsLockA);
			numCarsA++;
			lock_release(prioCarsLockA);
		}
	}
	else if(vehicledirection== 1){ // lane B
		if(vehicletype == 0){
			lock_acquire(prioCarsLockB);
			numCarsB++;
			lock_release(prioCarsLockB);
		}
	}
	else if(vehicledirection== 2){ // lane C
		if(vehicletype == 0){
			lock_acquire(prioCarsLockC);
			numCarsC++;
			lock_release(prioCarsLockC);
		}
	}

	if(turndirection==0){//turn direction of zero will be a right turn
        turnright(vehicledirection,vehiclenumber,vehicletype);

    }
    else if (turndirection==1){// To prevent deadlocks, we must limit to 2 left turns concurrently
		int spl;
		lock_acquire(leftTurnLock); // acquire lock so we can look at numLeftTurns variable
		if(numLeftTurns < 2){ // if less numLeftTurns <= 1, go to the intersection
			numLeftTurns++;
			lock_release(leftTurnLock);

			turnleft(vehicledirection,vehiclenumber,vehicletype);

			lock_acquire(leftTurnLock); // decrement the value once we finish our left turrn
			numLeftTurns--;
			spl = splhigh(); // warning implciit declaration; ??????????????
			thread_wakeup(leftTurnLock); // wake up all sleeping locks
			splx(spl); // warning implciit declaration;???????
			lock_release(leftTurnLock);
		}
		else{
			lock_release(leftTurnLock); 
			while(1){ // since we couldnt go to the intersection first time around, keep loooping
				lock_acquire(leftTurnLock); // until the intersection becomes available
				if(numLeftTurns < 2){
					numLeftTurns++;
					lock_release(leftTurnLock);

					turnleft(vehicledirection,vehiclenumber,vehicletype);
					lock_acquire(leftTurnLock);
					numLeftTurns--;
					spl = splhigh();
					thread_wakeup(leftTurnLock);
					splx(spl);
					lock_release(leftTurnLock);
					break;
				}
				else{
					lock_release(leftTurnLock); // since intersection is busy, sleep the thread
					spl = splhigh(); // to prevent busy waiting
					thread_sleep(leftTurnLock);
					splx(spl);
				
				}
			}
		}
    }
}


/*
 * createvehicles()
 *
 * Arguments:
 *      int nargs: unused.
 *      char ** args: unused.
 *
 * Returns:
 *      0 on success.
 *
 * Notes:
 *      Driver code to start up the approachintersection() threads.  You are
 *      free to modify this code as necessary for your solution.
 */

int
createvehicles(int nargs,
		char ** args)
{
	int index, error;

	/*
	 * Avoid unused variable warnings.
	 */

	(void) nargs;
	(void) args;

	printlock = lock_create("printlock");
    ABlock = lock_create("ABlock");//call create locks for the intersection zones
    BClock = lock_create("BClock");
    CAlock = lock_create("CAlock");
	leftTurnLock = lock_create("leftTurnLock");

	// locks to prioritize cars over trucks in each lane
	prioCarsLockA = lock_create("prioCarsLockA");
	prioCarsLockB = lock_create("prioCarsLockB");
	prioCarsLockC = lock_create("prioCarsLockC");
	
	/*
	 * Start NVEHICLES approachintersection() threads.
	 */
	
	for (index = 0; index < NVEHICLES; index++) {

		error = thread_fork("approachintersection thread",
				NULL,
				index,
				approachintersection,
				NULL
				);

		/*
		 * panic() on error.
		 */

		if (error) {

			panic("approachintersection: thread_fork failed: %s\n",
					strerror(error)
				 );
		}
	}

	return 0;
}
