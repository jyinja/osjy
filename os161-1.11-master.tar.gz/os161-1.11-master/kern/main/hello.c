//Jason Yin hello.c for os161

void hello(void){
    kprintf("Hello World\n");
}
