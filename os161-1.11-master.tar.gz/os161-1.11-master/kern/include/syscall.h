#ifndef _SYSCALL_H_
#define _SYSCALL_H_

/*
 * Prototypes for IN-KERNEL entry points for system call implementations.
 * Belongs in kern/include
 */

int sys_reboot(int code);
int sys_getpid(void);//added other system calls from this line and below
int sys_getppid(void);
int sys_fork(struct trapframe *tf, int32_t *retval);
//pid_t sys_fork(void);
int sys_execv(char *prog, char **args);
int sys_waitpid(int pid, int *status, int options,int *returncode);
int sys__exit(int exitcode);
#endif /* _SYSCALL_H_ */
