//fork system call
//copies the current process
//sample function declaration = pid_t fork(void);
//errors are EAGAIN when too many processes already exist and ENOMEM when not enough sufficient virtual memory available for the new forked process
//on success, fork returns twice once in parent and once in child. Child returns 0 and parent returns the process ID of the new child process
//on error/fail, no new process is created and fork only returns once which it will return -1, errno is set to the error encountered accordingly.
//#include <lib.h>

//error codes include EAGAIN (too many processes already exist) or ENOMEM (sufficient virtual memory not available)

/*
#include <types.h>
#include <kern/errno.h>
#include <uio.h>
#include <lib.h>
#include <machine/spl.h>
#include <machine/trapframe.h>
#include <thread.h>
#include <curthread.h>
#include <addrspace.h>
#include <vm.h>
#include <vfs.h>
#include <vnode.h>
#include <syscall.h>

#include <test.h>
#include <synch.h>

#include <clock.h>*/
/*
#include <types.h>
#include <kern/errno.h>
#include <lib.h>
#include <machine/pcb.h>
#include <machine/spl.h>
#include <machine/trapframe.h>
#include <kern/callno.h>
#include <kern/unistd.h>
#include <syscall.h>
#include <thread.h>
#include <curthread.h>
#include <addrspace.h>
#include <kern/limits.h>
#include <uio.h>
#include <vfs.h>
#include <vnode.h>
#include <vm.h>


#include <test.h>
#include <synch.h>

#include <clock.h>*/
#include <types.h>
#include <kern/errno.h>
#include <array.h>//added so we can add to children array of thread struct
#include <lib.h>
#include <machine/pcb.h>
#include <machine/spl.h>
#include <machine/trapframe.h>
#include <kern/callno.h>
#include <kern/unistd.h>
#include <syscall.h>
#include <thread.h>
#include <curthread.h>
#include <addrspace.h>
#include <kern/limits.h>
#include <uio.h>
#include <vfs.h>
#include <vnode.h>
#include <vm.h>


#include <test.h>
#include <synch.h>

#include <clock.h>
int sys_fork(struct trapframe *tf, int32_t *retval){
    //1. create pid when creating a new process add it to your process table
    //2. copy trapframe
    //3. copy address space
    //4. call thread_fork(), the child will start executing md_forkentry (implement the md_forkentry)
    int spl;
    int er = 0;
    
	*retval = -1;
	
	// pid has pid, it has parent pid,
    //Make sure trapframe is not null before we get started
    assert(tf != NULL);
	
    //sys_getpid(&id);
    //id = curthread->t_pid;
    struct thread *child_thread = NULL;

    /*copy parent's trap frame*/

    struct trapframe *parent_trapframe_copy = kmalloc(sizeof(struct trapframe)); //allocate space for trap frame 
    if(parent_trapframe_copy==NULL){ // no memory available to allocate space, return error
        kfree(parent_trapframe_copy); //free the parent trapframe copy on the kernel 
        return ENOMEM;           //and return the error code
    }
    spl = splhigh();  //no interrupt
   // kprintf("memcopy in fork...\n");
    memcpy(parent_trapframe_copy,tf, sizeof(struct trapframe));

    splx(spl);
    /*Finished copying the trapframe*/
    //call thread_fork, there is warning for arg 4 of this line below
   // kprintf("calling thread_fork...\n");

    er = thread_fork(curthread->t_name, (void*)parent_trapframe_copy, 0 , md_forkentry,&child_thread ); //md_forkentry is in syscall.c, there is a warning for that as incompatible pointer type
    //check er 

    //kprintf("# of children of curthread: %d\n",array_getnum(curthread->children));
    //return child pid
	
    if(er){ // if we received an error, free our stuff and the nreturn -1 as error.
	kfree(child_thread);
	return er; // return the error code from thread_fork

    }else{
		*retval = child_thread->t_pid;
 	return 0;
   }

}
