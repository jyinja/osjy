//execv system call
//executes a program


#include <types.h>
//#include <errno.h>
#include <kern/errno.h>
#include <lib.h>
#include <machine/pcb.h>
#include <machine/spl.h>
#include <machine/trapframe.h>
#include <kern/callno.h>
#include <kern/unistd.h>
#include <syscall.h>
#include <thread.h>
#include <curthread.h>
#include <addrspace.h>
#include <synch.h>
#include <uio.h>
#include <vfs.h>
#include <vnode.h>
#include <kern/limits.h>
#include <machine/vm.h>
#include <vm.h>
#include <kern/stat.h>
#include <fs.h>
#include <test.h>


#include <clock.h>

#define MAX_P_LENGTH 100
#define MAX_PARAM_NUM 100
//code based off runprogram.c
//sample function declaration= int execv(const char *program, char**args);

//replaces currently executing program with newly loaded program. This occurs within one process; process ID is unchanged.
//pathname of the program to run is passed as program. The args argument is an array of 0-terminated strings and array itself should be terminated by a NULL pointer.
//The argument strings should be copied into the new process as the new process's argv[] array. In the new process, argv[argc] must be NULL.
//argv[0] in the new process contains the name that was used to invoke the program. This is not necessarily the same as program paramter, and furthermore is only a convention and should not be enforced by kernel.
//process file table and current working directory not modified by execv

//on success, execv does not return, instead the new program begins executing. On fail, execv returns -1 and sets errno to suitable error code
//ERROR CODES BELOW:
//ENODEV when device prefix of program does not exist
//ENOTDIR when a non-final component of program parameter was not a directory
//ENOENT program did not exist
//EISDIR when program is a directory
//ENOEXEC when program is not a recognizable executable file format, happens possibly because of wrong platform or contained invalid fields
//ENOMEM when insufficient virtual memory is available
//E2BIG when total size of argument strings is too large
//EIO when hard I/O error occurred
//EFAULT when one of the args is invalid pointer X
int sys_execv(char *prog, char **args){
    //1. copyin the args from user space to kernel space
    //2. allocate a stack on it as_define_stack()
    //3. activate it as_activate()
    //4. copyout args back onto the new stack
    //5. return to usermode by calling md_usermode()
    /*size_t a;
    int err=0;
    char programname[NAME_MAX];//defined in limits.h as longest filename not including null terminator
    err = copyinstr(prog,programname,NAME_MAX,&a);//copyinstr will return int zero on success and otherwise when not
    //source manual page: https://www.freebsd.org/cgi/man.cgi?query=copyinstr&sektion=9&n=1

    if(strcmp(programname,"")==0){
        return EISDIR; //strcmp returns zero if equal
    }
    if(err){
        return err;
    }
    char *params[MAX_PARAM_NUM];//the arguments passed in by user
    err = copyin(args, params,MAX_PARAM_NUM);
    if(err){
        return err;//possible error code
    }

    int leng = 0;
    int index = 0;
    char *kernbuffer[MAX_PARAM_NUM];
    while(params[index]!=NULL){
        kernbuffer[index] = kmalloc(MAX_P_LENGTH);

        if(kernbuffer[index]==NULL){
            return ENOMEM;//insufficient virtual memory
        }
        err = copyin( (const userptr_t)params[index],(char*)kernbuffer[index],(size_t)MAX_P_LENGTH );

        if(err){

        }
    }*/
    struct vnode *v;
    vaddr_t firstptr;
    vaddr_t stackptr;
    int results;
    int i = 0;
    size_t size;
    size_t paramleng;

    int kernelargc;
    char **kernelargv;
    char *programname = (char *)kmalloc(PATH_MAX);

    while(args[i]!=NULL){
        i++;//count amount of arguments
    }
    kernelargc = i;

    //use copyinstr to check valid program name from userspace into kernel space
    if(prog == NULL){
        /*
        errno = EFAULT;
        return -1;//invalid pointer*/
        return EFAULT;
    }
    copyinstr( (userptr_t)prog,programname,PATH_MAX,&size);

    //allocate the kernel for the args
    kernelargv = (char **)kmalloc(sizeof(char*));

    //now copy args from userspace to kernel space
    for(i =0;i<kernelargc;i++){
        int leng = strlen(args[i])+1;
        kernelargv[i] = (char*)kmalloc(leng);
        copyinstr( (userptr_t)args[i], kernelargv[i],leng,&paramleng);
    }
    kernelargv[kernelargc] = NULL;//null terminator

    results=vfs_open(programname,O_RDONLY,&v);//open executable, vfs_open is found under kern/fs/vfs/vfspath.c
    if(results){
        /*
        errno=results;//could return an error code
        return -1;*/
        return results; //from vfs_open there are Error codes that may be returned from open operation
    }
    if(curthread->t_vmspace!=NULL){
        //destroy addr space so a new executable may load
        as_destroy(curthread->t_vmspace);//addrspace.c
        curthread->t_vmspace=NULL;
    }
    //assert a new thread, make a new address space
    assert(curthread->t_vmspace == NULL);
    curthread->t_vmspace=as_create();
    if(curthread->t_vmspace==NULL){
        vfs_close(v);
        /*
        errno = ENOMEM;
        return -1;//insufficient virtual memory
        */
        return ENOMEM;
    }

    as_activate(curthread->t_vmspace);//activate
    results = load_elf(v,&firstptr);//load executable
    if(results){
        vfs_close(v);
        /*
        errno=results;//may result in errorcode
        return -1;
        */
        return results;
    }
    vfs_close(v);//close file cause done

    results = as_define_stack(curthread->t_vmspace,&stackptr);//user stack in addr space
    if(results){
        /*
        errno= results;
        return -1;
        */
        return results;
    }

    //align arguments by 4. copy last arg in top of stack.
    unsigned int param_stack[kernelargc];
    for(i=kernelargc-1;i>=0;i--){
        int len = strlen(kernelargv[i]);
        int p_length = len%4;//packed
        if(p_length>0){
            p_length = ((int)(len/4)+1) * 4;

        }
        else if(p_length==0){
            p_length = len;

        }
        stackptr=stackptr-(p_length);//stack grows top to bottom
        copyoutstr(kernelargv[i],(userptr_t)stackptr, len, &paramleng);
        param_stack[i] = stackptr;
    }
	// padding is (4) - (len %4) .... i.e strlen = 7..... 7%4 = 3 .... 4-3 = 1; .
    //from kernel to user, copy out will copy kernel buffer into the stack of the user
    param_stack[kernelargc] = (int)NULL;
    for(i=kernelargc-1;i>=0;i--){
        stackptr = stackptr-4;
        copyout(&param_stack[i], (userptr_t)stackptr, sizeof(param_stack[i])); //copyout found in lib.copyinout.c
    }

    kfree(kernelargv);
    md_usermode(kernelargc,(userptr_t)stackptr, stackptr, firstptr);//change to usermode
    //panic?
    panic("...");

    //errno = EINVAL;
    //return -1;

    return EINVAL;
}
