//getpid system call, configure the file src/kern/conf/conf.kern and add 'file userprog/getpid.c'
//sample function declaration = pid_t getpid(void);
//#include <lib.h>

#include <types.h>
#include <lib.h>
//#include <syscall.h>
#include <curthread.h>
#include <thread.h>
#include <clock.h>
//#include <copyinout.c>
//pid_t is a signed integer
//according to man page, getpid returns process ID of calling process. There are no errors that occur
int sys_getpid(void){ //simplest system call just get pid of executing process
	
    return curthread->t_pid;
    //return pidval



}
//must update struct thread in kern/include/thread.h with adding pid_t t_pid to the struct
