//exit system call
//_exit will terminate process
/*
#include <types.h>
//#include <lib.h>
#include <kern/errno.h>
#include <uio.h>
#include <lib.h>
//#include <spl.h>
//#include <mips/trapframe.h>
#include <thread.h>
#include <curthread.h>
#include <addrspace.h>
#include <vm.h>
#include <vfs.h>
#include <vnode.h>
#include <syscall.h>

#include <test.h>
#include <synch.h>

#include <clock.h>*/
#include <types.h>
//#include <errno.h>
#include <kern/errno.h>
#include <lib.h>
#include <machine/pcb.h>
#include <machine/spl.h>
#include <machine/trapframe.h>
#include <kern/callno.h>
#include <kern/unistd.h>
#include <syscall.h>
#include <thread.h>
#include <curthread.h>
#include <addrspace.h>
#include <synch.h>
#include <uio.h>
#include <vfs.h>
#include <vnode.h>
#include <kern/limits.h>
#include <machine/vm.h>
#include <vm.h>
#include <kern/stat.h>
#include <fs.h>
#include <test.h>


#include <clock.h>
//sample function declaration = void _exit(int exitcode);
//cause the current process to exit and the exitcode is reported back to other processes via the waitpid() call.
//The process ID of exiting process should not be reused until all processes interested in collecting the exit code with waitpid have done so.
//what "interested" means is left vague and should be up to our design
//does not return and no errors to report
int sys__exit(int exitcode){ //REVERSED DECISION: changed from int sys__exit to void sys__exit

    //process id of exiting process can't be reused if there are other processes 'interested' or waiting on it
    //do not put exited pid back to available pid pool blindly
    //exitcode is the exitcode that will be assigned

    pid_t pid = curthread->t_pid;
    struct thread *p = array_getguy(p_table, curthread->t_pid-1);
   // int err,i;
    assert(p!=NULL);
    curthread->exit_status = exitcode; //set exit status to the param exitcode

    /* If this process has any children, set the children PPID to 1 so that it will now be assigned to the KERNEL. We can do it in thread_exit or thread_Destory */
	
    thread_exit();

    return 0;
}
