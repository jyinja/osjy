//waitpid system call
//wait for a process to exit
/*
#include <types.h>
//#include <lib.h>
#include <kern/errno.h>
#include <uio.h>
#include <lib.h>
//#include <spl.h>
//#include <mips/trapframe.h>
#include <thread.h>
#include <curthread.h>
#include <addrspace.h>
#include <vm.h>
#include <vfs.h>
#include <vnode.h>
#include <syscall.h>

#include <test.h>
#include <synch.h>

#include <clock.h>
------------------
#include <types.h>
#include <kern/errno.h> //this is kern/errno.h
#include <lib.h>
#include <machine/pcb.h>
#include <machine/spl.h>
#include <machine/trapframe.h>
#include <kern/callno.h>
#include <kern/unistd.h>
#include <syscall.h>
#include <thread.h>
#include <curthread.h>
#include <addrspace.h>
#include <kern/limits.h>
#include <uio.h>
#include <vfs.h>
#include <vnode.h>
#include <vm.h>*/
#include <types.h>
//#include <errno.h>
#include <kern/errno.h>
#include <lib.h>
#include <machine/pcb.h>
#include <machine/spl.h>
#include <machine/trapframe.h>
#include <kern/callno.h>
#include <kern/unistd.h>
#include <syscall.h>
#include <thread.h>
#include <curthread.h>
#include <addrspace.h>
#include <synch.h>
#include <uio.h>
#include <vfs.h>
#include <vnode.h>
#include <kern/limits.h>
#include <machine/vm.h>
#include <vm.h>
#include <kern/stat.h>
#include <fs.h>
#include <test.h>


#include <clock.h>

//The options arg should be 0. You are not required to implement any options however your system should check to make sure that options you do not support are not requested


//sample function declaration = pid_t waitpid(pid_t pid, int *status, int options);

//wait for process specified by pid to exit and return its exitcode in the integer pointed to by status.
//If that process has exited already then waitpid returns immediately. If that process does not exist, then waitpid fails.
//What it means for a process to move from "has exited already" to "does not exist" is up to our design decision

//if process P is "interested" in exit code of process Q, then process P should be able to find out that exit code by calling waitpid even if Q exits somewhat before the time P calls waitpid.

//You might implement restrictions or requirements on who may wait for which processes like Unix does. You might also add a system call for one process to express interest in another process's exit code.
//If you do what is said above, be sure to write a man page for that new system call and discuss rationale for your choices in design document.

//Note that in the absense of restrictions on who may wait for what, it is possible to set up situations that result in deadlock. Your system must protect itself from these situations, either by prohibiting them or detect and resolve them

// In order to make the userlevel code that ships with Os161 to work, assume that a parent process is always interested in the exitcode of its child processes generated with fork(), unless it does something special to indicate otherwise
//If you desire, you may implement UNIX option WNOHANG; this causes waitpid, when called for a process that has not yet exited, to return 0 immediately instead of waiting
//you may also make up your own options if you find it helpful but document anything you make up

//Returns the process ID whose exit status is reported in status parameter. This is always the value of pid. If you implement WNOHANG, and WNOHANG is given, and the process specified by pid has not yet exited then waitpid returns 0
//On error, return -1 and errno is set to suitable error code for the error condition

//following are error codes:
//EINVAL when the options argument requested is invalid or unsupported
//EFAULT when status argument was invalid pointer_safety
//ESRCH is traditional Unix error code for no such process althought this code is not defined in OS161 base system, so I guess don't worry about it.
int sys_waitpid(int pid,int *status,int options,int *returncode/*,int *status, int flags*/){
    //make an 'interest system' like only parents may wait for children, prevent deadlocks
    //return pid with status assigned to exit status on success
    //if error, return -1 and set returncode to error code

// struct thread* parentThread = get_process(pid);
// search thru and check if pid actually is parent of this thread
 /* check if pid exists in process table ->
  check if pid's parent is the current Thread, because we dont want to wait for thread thats not
  our child. if parent does not exist return -1
	Then use semaphore to block the parent thread while the child runs.
	at thread exit of child, free() the semaphore to unblock parent.

	 */
	 
	 //first check if arguments are correct.
	 if(status==NULL){ // make sure status is not empty
        *returncode=-1;
        return EFAULT;
    }
	if(((int) status % 4) != 0){ //make sure pointer is aligned properly
		*returncode=-1;
        return EFAULT;
	}
	if(options != 0){ // we can only handle the 0 option flag
		*returncode=-1;
        return EINVAL;
	}
	// get the process from pid 
	if(pid < 1){ // make sure the pid number argument is correct
		*returncode=-1;
        return EINVAL;
	}
    struct thread* t = array_getguy(p_table, pid-1);
    if(t==NULL){ // if process was not found, means it doesnt exist and we can just return the invalid argument error 
        *returncode = -1;
        return EINVAL; //if the place in the process table/array is null
    }

	//make sure we have children in our cur thread, if we dont have any children, we can't wait for anything
	if(curthread->children == NULL){ // if children is null, means we got no children in our parent thread
        *returncode = -1;
        return EINVAL; 
    }

	if(array_getnum(curthread->children) == 0){ // if we have child array, but 0 children in there then we have 0 processes
        *returncode = -1;
        return EINVAL; // return error
    }
	if(t->parent_pid != curthread->t_pid){ // if parent pid doesnt belong this is an error
		 *returncode = -1;
         return EINVAL; // return error
	}

	// if process already exited, return the pid number we found
	if(t->has_exited){
		return pid;
	}
	// now we know that this process belongs to us, and we know it hasn't exited yet we can work on this
	// now we can block this sempahore in the child pid, then in thread_Exit() we free it's own semaphore with V
	P(t->sphore); // this will block this current thread
	// itll be freed after this point, so return the pid number
	*returncode = pid;


	/*
    //acquire lock
    lock_acquire(t->lk);
    pid_t mpid = curthread->t_pid;

    int ans, sts;
    ans = copyin((userptr_t)status, &sts, sizeof(status));//copy user pointer

    if(curthread->parent_pid!=0 && ans){//if parent DNE, meaning nothing is waiting for this thread
        lock_release(t->lk);
        *returncode = -1;
        return ans;
    }
    if(pid<=mpid || array_getnum(p_table)>pid){
        lock_release(t->lk);
        *returncode = -1;
        return EINVAL;
    }


    //maybe conditional var wait?
    *status = t->exit_status;//report exit status
    *returncode = pid;
    lock_release(t->lk);

    array_setguy(p_table, pid-1, NULL);//empty out the pid slot of the p_table
	*/
    return 0;
}
