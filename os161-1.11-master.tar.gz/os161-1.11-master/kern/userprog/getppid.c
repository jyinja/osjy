//getppid system call
//#include <lib.h>

#include <types.h>
#include <lib.h>
//#include <syscall.h>
#include <curthread.h>
#include <thread.h>
#include <clock.h>
//#include <copyinout.h>
//return process ID of the parent of the calling process, this will either be the ID of process that created this process using fork (if parent has not terminated)
//or -1 if parent has already terminated
int sys_getppid(void){
    //no error handling necessary here, return the current thread parent process ID, or -1 if parent process terminated already
    //struct thread *parent = curthread->t_pid;//t_pid is the added attribute to the thread struct
    //int32_t return_pid = parent->t_pid;
    //return return_pid;
    if(curthread->has_exited!=0){
        return -1;
    }
    else{
        return curthread->parent_pid; //parent ID attribute needed
    }
}
