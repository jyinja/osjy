/*
 * Synchronization primitives.
 * See synch.h for specifications of the functions.
 */

#include <types.h>
#include <lib.h>
#include <synch.h>
#include <thread.h>
#include <curthread.h>
#include <machine/spl.h>

////////////////////////////////////////////////////////////
//
// Semaphore.

struct semaphore *
sem_create(const char *namearg, int initial_count)
{
	struct semaphore *sem;

	assert(initial_count >= 0);

	sem = kmalloc(sizeof(struct semaphore));
	if (sem == NULL) {
		return NULL;
	}

	sem->name = kstrdup(namearg);
	if (sem->name == NULL) {
		kfree(sem);
		return NULL;
	}

	sem->count = initial_count;
	return sem;
}

void
sem_destroy(struct semaphore *sem)
{
	int spl;
	assert(sem != NULL);

	spl = splhigh();
	assert(thread_hassleepers(sem)==0);
	splx(spl);

	/*
	 * Note: while someone could theoretically start sleeping on
	 * the semaphore after the above test but before we free it,
	 * if they're going to do that, they can just as easily wait
	 * a bit and start sleeping on the semaphore after it's been
	 * freed. Consequently, there's not a whole lot of point in
	 * including the kfrees in the splhigh block, so we don't.
	 */

	kfree(sem->name);
	kfree(sem);
}

void
P(struct semaphore *sem)
{
	int spl;
	assert(sem != NULL);

	/*
	 * May not block in an interrupt handler.
	 *
	 * For robustness, always check, even if we can actually
	 * complete the P without blocking.
	 */
	assert(in_interrupt==0);

	spl = splhigh();
	while (sem->count==0) {
		thread_sleep(sem);
	}
	assert(sem->count>0);
	sem->count--;
	splx(spl);
}

void
V(struct semaphore *sem)
{
	int spl;
	assert(sem != NULL);
	spl = splhigh();
	sem->count++;
	assert(sem->count>0);
	thread_wakeup(sem);
	splx(spl);
}

////////////////////////////////////////////////////////////
//
// Lock.

struct lock *
lock_create(const char *name)
{
	struct lock *lock;

	lock = kmalloc(sizeof(struct lock));
	if (lock == NULL) {
		return NULL;
	}

	lock->name = kstrdup(name);//returns pointer of the string name which is a duplicate
	if (lock->name == NULL) {
		kfree(lock);
		return NULL;
	}

	// add stuff here as needed
	lock->heldbool=0; //if held or not
	lock->owner = NULL; //the struct of owner/holder defaults to nothing at the creation of lock
	return lock;
}

void
lock_destroy(struct lock *lock)
{
	assert(lock != NULL);

	// add stuff here as needed

	kfree(lock->name);//free the attribute name before the lock itself
	kfree(lock);
}

void
lock_acquire(struct lock *lock)
{
	// Write this

	//(void)lock;  // suppress warning until code gets written
    int priority;
    assert(lock!=NULL);//check if lock exists
    assert(in_interrupt==0);//may not block while in interrupt handler

    priority = splhigh();//turns off interrupts
    assert(!lock_do_i_hold(lock));

    while(lock->heldbool== 1 && lock->owner != curthread){
       thread_sleep(lock); // while held, thread sleep
    }
    lock->heldbool = 1;
    lock->owner = curthread;
    splx(priority);//this machine code define function sets priority level to intermediate level done atomically meaning while execution there won't be interference
    //note: splx will set priority level to whatever argument is passed in
}

void
lock_release(struct lock *lock)
{
	// Write this

	//(void)lock;  // suppress warning until code gets written
	int priority;
	assert(lock !=NULL);
	assert(lock->heldbool);
	assert(lock_do_i_hold(lock));//assertion statements to check lock existence and attributes
	priority=splhigh();//turns off interrupts
	lock->heldbool = 0;
	lock->owner = NULL;//releasing a lock will set the held boolean to zero and owner to null
	thread_wakeup(lock);
	splx(priority);

}

int
lock_do_i_hold(struct lock *lock)
{
	// Write this

	//(void)lock;  // suppress warning until code gets written

	//return 1;    // dummy until code gets written
	assert( lock != NULL );//check for existence of lock
	if(lock->heldbool==0){
        return 0;//if thread has not held lock then return zero
	}

	if(lock->owner == curthread){
        return 1;//if the owner of the lock is the current thread return 1
	}
	else{//else return zero meaning the owner of the lock is not matching with current thread
        return 0;
	}
}

////////////////////////////////////////////////////////////
//
// CV specs said to ignore stub code for conditional variables


struct cv *
cv_create(const char *name)
{
	struct cv *cv;

	cv = kmalloc(sizeof(struct cv));
	if (cv == NULL) {
		return NULL;
	}

	cv->name = kstrdup(name);
	if (cv->name==NULL) {
		kfree(cv);
		return NULL;
	}

	// add stuff here as needed

	return cv;
}

void
cv_destroy(struct cv *cv)
{
	assert(cv != NULL);

	// add stuff here as needed

	kfree(cv->name);
	kfree(cv);
}

void
cv_wait(struct cv *cv, struct lock *lock)
{
	// Write this
	///(void)cv;    // suppress warning until code gets written
	///(void)lock;  // suppress warning until code gets written
	int spl;
	assert(cv!=NULL);
	assert(lock!=NULL);//make sure we have good parameters

	spl = splhigh();//off interrupts
	lock_release(lock);
	thread_sleep(cv);

	lock_acquire(lock);
	splx(spl);
}

void
cv_signal(struct cv *cv, struct lock *lock)
{
	// Write this
	///(void)cv;    // suppress warning until code gets written
	///(void)lock;  // suppress warning until code gets written
	assert(cv!=NULL);
	assert(lock!=NULL);
	int spl = splhigh();
	lock_release(lock);
	thread_wakeup(cv);//wake up single waiting thread on lock
	lock_acquire(lock);
	splx(spl);
}

void
cv_broadcast(struct cv *cv, struct lock *lock)
{
	// Write this
	///(void)cv;    // suppress warning until code gets written
	///(void)lock;  // suppress warning until code gets written
	//possibly important for exit.c
	int spl;
	assert(cv!=NULL);
	assert(lock!=NULL);
	spl = splhigh();
	lock_release(lock);
	thread_wakeup(cv);
	lock_acquire(lock);
	splx(spl);//return usermode
}
