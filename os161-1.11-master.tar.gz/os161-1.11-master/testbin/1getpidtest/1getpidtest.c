/*
 * Simple program to test getpid() call.
 * */

#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <err.h>

/*
 * This is used by all processes, to try to help make sure all
 * processes have a distinct address space.
 */
//static volatile int mypid;
int
main(int argc, char *argv[])
{
	printf("\n ==-- starting getpid() test2 --== \n");
	printf("\n1. Get pid of first process:%d", getpid());
	printf("\nforking...\n");
	int pid = fork();
	printf("\n1.Get pid of processes after forking:%d", getpid());
	
	exit(0);
	return 0;
}
