/*
 * Simple program to test execv and fork() call.
 * */

#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <err.h>

/*
 * This is used by all processes, to try to help make sure all
 * processes have a distinct address space.
 */
//static volatile int mypid;
int
main(int argc, char *argv[])
{	printf("\n ==-- starting execv() test3 --== \n");
	char *filename="/testbin/add";
	char *args[4];
	pid_t pid;
	args[0] = "add";
	args[1] = "3";
	args[2]= "4";
	args[3] = NULL;

	execv(filename,args);

	/*printf("\n ==-- starting execv() test3 --== \n");
	char *filename="/testbin/add";
	char *args[4];
	pid_t pid;
	args[0] = "add";
	args[1] = "3";
	args[2]= "4";
	args[3] = NULL;
	printf("trying to fork...\n");
	pid = fork();
	printf("did fork\n");
	if (pid == 0 ){
        execv(filename,argv);
	}
	printf("3execvtest done.\n");*/
	return 0;
}
