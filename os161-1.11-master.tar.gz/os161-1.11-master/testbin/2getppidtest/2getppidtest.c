/*
 * Simple program to test getpid() call.
 * */

#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <err.h>

/*
 * This is used by all processes, to try to help make sure all
 * processes have a distinct address space.
 */
//static volatile int mypid;
int
main(int argc, char *argv[])
{
	printf("\n ==-- starting getppid() test --== \n");
	
	int ppid = getppid();
	printf("Get ppid of this process: %d\n", ppid);
	printf("\n forking...\n");
	int pid = fork();
	if(pid == 0){
		printf("Get PPID of child process: %d", getppid());
		printf("\n forking inside the child process...\n");

		int pid2 = fork();
				if(pid2 ==  0){
					printf("Get PPID of child in child process: %d", getppid());
					exit(1);	
			}
		exit(1);
	}
	return 0;
}
