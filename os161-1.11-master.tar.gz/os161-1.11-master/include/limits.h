#ifndef _KERN_LIMITS_H_
#define _KERN_LIMITS_H_

/* Longest filename (without directory) not including null terminator */
#define NAME_MAX  255

/* Longest full path name */
#define PATH_MAX   1024

#define ARG_MAX (1024*64) //maximum bytes for exec func

#define PID_MIN 1//pid management system
#define PID_MAX 32767

#define MAX_RUNNING_PROCS 256
#endif /* _KERN_LIMITS_H_ */
